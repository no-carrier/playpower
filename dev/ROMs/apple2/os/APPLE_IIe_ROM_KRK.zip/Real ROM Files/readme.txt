		   /*/*/*//*/*/*//*/*/*//*/*/*//*/*/*//*/*/
		   /*/                                  /*/
		   /*/   Apple //e Enhanced ROM images  /*/
		   /*/     with Monitor Debug Hacks     /*/
		   /*/         January 2, 2009          /*/
		   /*/*/*//*/*/*/*/*/*//*/*/*//*/*/*/*/*/*/
		   
If you tire of the emulator and want to play with the real thing, here are the CD and EF ROM images with the debugging modifications added. 

Eric
