#include "m37710cm.h"
#define EXECUTION_MODE EXECUTION_MODE_M0X0
#include "m37710op.h"
