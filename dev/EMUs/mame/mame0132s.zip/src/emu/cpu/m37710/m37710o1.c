#include "m37710cm.h"
#define EXECUTION_MODE EXECUTION_MODE_M0X1
#include "m37710op.h"
