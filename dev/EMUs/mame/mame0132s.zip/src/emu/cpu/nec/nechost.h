/*****************************************************************************/
/* host dependent types                                                      */

#define BIGCASE

#include "cpuintrf.h"

typedef char BOOLEAN;

typedef UINT8 BYTE;
typedef UINT16 WORD;
typedef UINT32 DWORD;
