/*****************************************************************************/
/* host dependent types                                                      */

#define BIGCASE

#include "mamecore.h"

typedef char BOOLEAN;

typedef UINT8 BYTE;
typedef UINT16 WORD;
typedef UINT32 DWORD;
