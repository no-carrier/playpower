/*
    Generate the tms9900 emulator
*/

#include "tms9900.h"

#define TMS99XX_MODEL TI990_10_ID

#include "99xxcore.h"
