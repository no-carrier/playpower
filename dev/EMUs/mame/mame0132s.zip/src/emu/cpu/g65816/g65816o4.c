#include "g65816.h"
#include "g65816cm.h"
#define EXECUTION_MODE EXECUTION_MODE_E
#include "g65816op.h"
